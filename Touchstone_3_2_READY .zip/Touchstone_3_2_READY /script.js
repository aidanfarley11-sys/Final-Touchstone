// Touchstone Task 3.2 – Web Storage (sessionStorage + localStorage)
document.addEventListener("DOMContentLoaded", () => {
  // Subscribe (all pages)
  const subscribeBtn = document.getElementById("subscribeBtn");
  if (subscribeBtn) {
    subscribeBtn.addEventListener("click", () => alert("Thank you for subscribing."));
  }

  // CART (Gallery) using sessionStorage
  const CART_KEY = "cartItems";

  function getCart() {
    return JSON.parse(sessionStorage.getItem(CART_KEY) || "[]");
  }

  function saveCart(cart) {
    sessionStorage.setItem(CART_KEY, JSON.stringify(cart));
  }

  function renderCartList() {
    const listEl = document.getElementById("cartItemsList");
    if (!listEl) return;

    listEl.innerHTML = "";
    const cart = getCart();

    if (cart.length === 0) {
      listEl.innerHTML = "<li>Your cart is empty.</li>";
      return;
    }

    cart.forEach((item) => {
      const li = document.createElement("li");
      li.textContent = item;
      listEl.appendChild(li);
    });
  }

  // Add to Cart buttons
  document.querySelectorAll(".addToCartBtn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const itemName = btn.dataset.item || "Item";
      const cart = getCart();
      cart.push(itemName);
      saveCart(cart);
      alert("Item added to the cart.");
    });
  });

  // View Cart modal open/close
  const viewCartBtn = document.getElementById("viewCartBtn");
  const cartModal = document.getElementById("cartModal");
  const closeCartBtn = document.getElementById("closeCartBtn");

  if (viewCartBtn && cartModal) {
    viewCartBtn.addEventListener("click", () => {
      renderCartList();
      cartModal.style.display = "block";
      cartModal.setAttribute("aria-hidden", "false");
    });
  }

  if (closeCartBtn && cartModal) {
    closeCartBtn.addEventListener("click", () => {
      cartModal.style.display = "none";
      cartModal.setAttribute("aria-hidden", "true");
    });
  }

  // Clear Cart + Process Order (both clear sessionStorage)
  const modalClearCartBtn = document.getElementById("modalClearCartBtn");
  const modalProcessOrderBtn = document.getElementById("modalProcessOrderBtn");

  function clearCart() {
    sessionStorage.removeItem(CART_KEY);
    renderCartList();
  }

  if (modalClearCartBtn) {
    modalClearCartBtn.addEventListener("click", () => {
      clearCart();
      alert("Cart cleared.");
    });
  }

  if (modalProcessOrderBtn) {
    modalProcessOrderBtn.addEventListener("click", () => {
      clearCart();
      alert("Thank you for your order.");
    });
  }

  // About/Contact form -> localStorage
  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const name = document.getElementById("name")?.value || "";
      const email = document.getElementById("email")?.value || "";
      const message = document.getElementById("message")?.value || "";

      const entry = { name, email, message, savedAt: new Date().toISOString() };
      localStorage.setItem("customOrder", JSON.stringify(entry));

      alert("Thank you for your message.");
      contactForm.reset();
    });
  }
});
