Touchstone Task 3.2 – Ready Files
Keep the HTML/CSS/JS together. Keep images in an images/ folder.
Gallery: Add to Cart uses sessionStorage; View Cart shows modal; Clear/Process clear cart.
About: Submit stores data in localStorage key 'customOrder'.
